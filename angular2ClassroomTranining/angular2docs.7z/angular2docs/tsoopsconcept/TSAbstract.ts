abstract class  Demo {
    name : string;
    greet(message){
        return  "hello" + message;
    }
}

let obj = new Demo();
obj.greet("test");
