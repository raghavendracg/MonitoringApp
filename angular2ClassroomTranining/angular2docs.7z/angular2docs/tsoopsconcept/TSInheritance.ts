//Inheritance in Type Script
class Foo {
    private _privateSample : string;
    protected protectedSample : string;
    public publicSample :  String;

    constructor() {
        this._privateSample = "Only in Foo";
        this.protectedSample = "Foo-Delivered-Instance";
        this.publicSample = "Foo-Delivered";
    }
}
class Baz extends Foo {
    constructor() {
        super();
        this.protectedSample = "Changed protected in Baz";
        this.publicSample = "Changed public in Baz";
    }
    print(): void {
        console.log(this.protectedSample);
        console.log(this.publicSample);
        console.log(this._privateSample);
    }
}
 var bazObj: Baz;
 bazObj = new Baz();
 bazObj.publicSample = "Changed public via Instance";
 bazObj.print();

 // Property Getter Setter

 class SampleSetter {
     
 }