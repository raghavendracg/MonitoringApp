Interface Greetable {
    greet(message: string):void;
    language : string;
}

class Greet implements Greetable {
    language =" English";
    greet (message: string) {
        console.log(message);
        console.log(this.language);
        
    }
}

let obj = new Greet();
obj.greet("I have been implemented via interface");

// indexer 

interface CarPart {
    [name: string]: string ;
}
class Test {
    part:CarPart={};
}

var testObj = new Test();
testObj["frame"] = "Frame";