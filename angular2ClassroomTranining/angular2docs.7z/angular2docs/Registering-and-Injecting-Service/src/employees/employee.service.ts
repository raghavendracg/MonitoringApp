import { Injectable } from '@angular/core'
import { IEmployee } from './employee'

@Injectable()
export class EmployeeService{
     getAllEmployees(): IEmployee[]{
        return [
            {
              id:101,
              name:'Ganesh'
            },
            {
              id:102,
              name:'Karthik'
            },
            {
              id:103,
              name:'Anil'
            }
        ]
    }
}