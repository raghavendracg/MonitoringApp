import { Component,Injectable,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import 'rxjs/Rx'; 
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
enableProdMode();

interface IGuest{
    id:number,
    name:string,
    contactNumber:string
}

@Injectable()
class GuestService{
    
    private url = '/app/guests.json';
    
    constructor(@Inject(Http) private http:Http){
        
    }
    
    getAllGuests():Observable<IGuest[]>{
        return this.http.get(this.url).map((response:Response)=><IGuest[]>response.json()).catch(this.handleError);
    }
    
    private handleError(error:Response){
        console.log(error);
        return Observable.throw(error.json().error || 'Server Error');
    }
}



@Component({
  selector: 'my-app',
  template: `<table class="table table-striped">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Contact</th>
        </tr>
    </thead>
    <tbody>
         <tr *ngFor="let guest of guests">
              <td>{{ guest.id }}</td>
              <td>{{ guest.name }}</td>
              <td>{{ guest.contactNumber }}</td>
          </tr>
     </tbody>
</table>`,
  providers: [ GuestService ]
})


export class GuestComponent implements OnInit{
   private guests:IGuest[];
    private errorMessage:any;
    
    constructor(@Inject(GuestService) private service:GuestService){
        
    }
    
    ngOnInit():void{
         this.service.getAllGuests().subscribe(guests=>this.guests = guests,error=>this.errorMessage=error);
    }
}

@NgModule({
  imports:      [ BrowserModule, HttpModule ],
  declarations: [ GuestComponent ],
  bootstrap:    [ GuestComponent ]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);

  