import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import {AppModule} from './appmodule'
platformBrowserDynamic().bootstrapModule(AppModule);