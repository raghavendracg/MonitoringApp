"use strict";
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var appmodule_1 = require('./appmodule');
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(appmodule_1.AppModule);
//# sourceMappingURL=main.js.map