var path = require('path');

var utils_aliases = [
    'app',
    'components',
    'directives',
    'services',
    'style',
    'fonts',
    'constants',
    'models',
    'reducers',
    'pipes',
    'utils'
].reduce(function (acc, dir) {
    acc[dir] = path.resolve('src', dir);
    console.log("define alias for " + dir + " => " + acc[dir]);
    return acc;
}, {});

utils_aliases['packageJson'] = path.join(__dirname, 'package.json');

module.exports = utils_aliases;
