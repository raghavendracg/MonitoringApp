export const Commands = {
    START: 'START'
};

export default Commands;