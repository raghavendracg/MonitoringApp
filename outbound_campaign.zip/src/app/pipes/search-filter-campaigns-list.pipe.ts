import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
   name: 'odSearchFilter'
})
export class SearchFilterPipe implements PipeTransform {
   transform(campaignData: any, searchValue: string): any {
      if (campaignData === undefined || searchValue === undefined) {
         return campaignData;
      } else {
         return campaignData.filter(function (res) {
            return res.name.toLowerCase().includes(searchValue.toLowerCase());
         })
      }
   }

}
