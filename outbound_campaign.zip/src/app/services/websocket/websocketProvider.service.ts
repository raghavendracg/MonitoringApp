import { Injectable } from '@angular/core';

// Services
import { CookieService } from 'ngx-cookie-service';
import { NotificationService } from './notification.service';
import { ErrorService } from '../error.service';
// Models
import { WsMessage } from '../../models/WsMessage';
import { WsRequestMessage } from '../../models/WsRequestMessage';
import { WsResponseMessage } from '../../models/WsResponseMessage';
import { KeyedCollection } from '../../models/KeyedCollection';
// Constants
import Commands from '../../constants/commands';
/// <reference path="../../../typings/sockjs/sockjs.d.ts" />

declare let EventBus: any;

/**
 * WebsocketProvider
 */
@Injectable()
export class WebsocketProvider {
    URL: string;
    handlers = {};
    eventBus: any;
    vertxURL: string = 'server-message';
    uid: any;
    agentId: any;
    myVertxCookie: string;
    serverEvent: string = 'ws.server.';
    mySocketSessionToken: string;
    clientEvent: string = 'ws.client.';
    isOpened: boolean = false;
    sockJsProtocols: any = ["websocket", "jsonp-polling", "xhr-streaming", "xdr-streaming", "xhr-polling", "xdr-polling", "iframe-htmlfile", "iframe-eventsource", "iframe-xhr-polling"];
    className: string = 'WebsocketProvider';
    // all requests are saved
    requests = new KeyedCollection<WsMessage>();
    MAXTIMEOUT: number = 60000; // 1MIN
    recInterval: number = 0;
    reason: string;
    reConnCount: number = 0;
    reConnIntervalID: number = 0;
    reConnectionFlag: boolean = true;
    techincalError: boolean = false;
    fullBaseURL: string;

    /**
     * Constructor
     */
    constructor(private cookieService: CookieService, private notificationService: NotificationService, private errorService: ErrorService) {
        this.myVertxCookie = this.getCookie('socketSessionId');
        this.mySocketSessionToken = this.getCookie('socketSessionToken');
        this.fullBaseURL = this.getCookie('client');

    }
    //////////////////////////////////////
    // Public
    //////////////////////////////////////

    /**
     * Open the websocket and add handlers on it
     */
    public open(url: string, reConnInterval: number, reConnTrial: number): void {
        if (!this.isOpened) {
            //            console.log(window.location.href.indexOf("vmw-console-it.prosodie"));
            this.URL = url;

            console.log(" this.mySocketSessionToken :  " + this.mySocketSessionToken);
            console.log(" this.myVertxCookie : " + this.myVertxCookie);

            this.eventBus = new EventBus(this.URL, { transports: this.sockJsProtocols, debug: true, secure: true });

            //opening an eventBus connection
            this.eventBus.onopen = (e) => {
                this.isOpened = true;
                this.callHandlers('open', e);
                console.log("[" + this.className + "] Websocket Connection is opened");
                this.eventBus.registerHandler(this.clientEvent + this.myVertxCookie, function(error, message) {
                    this.messageReceived(message);
                });

                if (this.reConnIntervalID > 0) {
                    clearInterval(this.reConnIntervalID);
                }
                this.reConnCount = 0;
                this.reConnectionFlag = true;
            }

            //receiving messages on eventBus
            this.eventBus.sockJSConn.onmessage = (e) => {
                this.messageReceived(e);
            }

            //error issues on an eventBus connection
            this.eventBus.sockJSConn.onerror = (e) => {
                console.error("[" + this.className + "] Error !" + e);
                this.callHandlers('close', e);
            }

            //close issues on an eventBus connection
            this.eventBus.sockJSConn.onclose = (e) => {
                console.log("[" + this.className + "] WebSocket Connection is closed!" + e);
                // this.callHandlers('close', e);

                switch (e.code) {
                    case 1000:
                        this.reason = "Normal closure, meaning that the purpose for which the connection was established has been fulfilled.";
                        break;
                    case 1001:
                        this.reason = "An endpoint is \"going away\", such as a server going down or a browser having navigated away from a page.";
                        break;
                    case 1002:
                        this.reason = "An endpoint is terminating the connection due to a protocol error";
                        break;
                    case 1003:
                        this.reason = "An endpoint is terminating the connection because it has received a type of data it cannot accept (e.g., an endpoint that understands only text data MAY send this if it receives a binary message).";
                        break;
                    case 1004:
                        this.reason = "Reserved. The specific meaning might be defined in the future.";
                        break;
                    case 1005:
                        this.reason = "No status code was actually present.";
                        break;
                    case 1006:
                        this.reason = "The connection was closed abnormally, e.g., without sending or receiving a Close control frame";
                        break;
                    case 1007:
                        this.reason = "An endpoint is terminating the connection because it has received data within a message that was not consistent with the type of the message (e.g., non-UTF-8 [http://tools.ietf.org/html/rfc3629] data within a text message).";
                        break;
                    case 1008:
                        this.reason = "An endpoint is terminating the connection because it has received a message that \"violates its policy\". This reason is given either if there is no other sutible reason, or if there is a need to hide specific details about the policy.";
                        break;
                    case 1009:
                        this.reason = "An endpoint is terminating the connection because it has received a message that is too big for it to process.";
                        break;
                    case 1010:
                        // Note that this status code is not used by the server, because it can fail the WebSocket handshake instead.
                        this.reason = "An endpoint (client) is terminating the connection because it has expected the server to negotiate one or more extension, but the server didn't return them in the response message of the WebSocket handshake. <br /> Specifically, the extensions that are needed are: " + e.reason;
                        break;
                    case 1011:
                        this.reason = "A server is terminating the connection because it encountered an unexpected condition that prevented it from fulfilling the request.";
                        break;
                    case 1015:
                        this.reason = "The connection was closed due to a failure to perform a TLS handshake (e.g., the server certificate can't be verified).";
                        break;
                    default:
                        this.reason = "Unknown reason";
                }

                console.log("[" + this.className + "] Error reason " + this.reason + "!");

                this.isOpened = false;
                this.reConnCount++;


                if (this.reConnectionFlag === true) {
                    //opening  an eventBus connection after some timeInterval
                    console.log("[" + this.className + "] Reconnecting Websocket Connection !" + e);
                    this.reConnectionHandler(url, reConnInterval, reConnTrial);
                }
            }

        } else {
            console.error("[" + this.className + "] Connection is already opened !");
        }
    }

    /**
     * Send data on websocket
     */
    public send(data: WsMessage) {
        if (this.isOpened) {
            console.log("[" + this.className + "] @" + this.serverEvent + this.myVertxCookie + " >> ");
            console.log(data);
            data.setSessionToken(this.myVertxCookie);
            let jsonData = JSON.stringify(data);
            //  const headers = JSON.stringify({"mySocketSessionToken":this.mySocketSessionToken });
            this.eventBus.publish(this.serverEvent + this.myVertxCookie, jsonData, { "mySocketSessionToken": this.mySocketSessionToken });
            this.requests.add(data.getMessageId(), data);
        } else {
            console.error("[" + this.className + "] Error send data - Connection is not opened !");
        }
    }

    /**
     * Handler on received message
     */
    public messageReceived(data: SJSMessageEvent) {
         let jsonData = JSON.parse(data.data);
         let jsonBody = JSON.parse(jsonData["body"]);
         let Pac4jCsrfTokenCookie = jsonBody["pack4jSessionToken"];

        //Validate browser session 
        if (Pac4jCsrfTokenCookie === this.mySocketSessionToken) {

            console.log("[" + this.className + "] << ");
            console.log(data);          

            let messageId = jsonBody["messageId"];
            let command = jsonBody["command"];
            let creationDate = jsonBody["creationDate"];

            // response
            let responseDate = jsonBody["responseDate"];
            let response = jsonBody["response"];
            let responseBody = jsonBody["responseBody"];

            let reponseMessage = new WsResponseMessage();
            reponseMessage.setMessageId(messageId);
            reponseMessage.setCreationDate(creationDate);
            reponseMessage.setResponseDate(responseDate);
            reponseMessage.setResponse(response);
            reponseMessage.setResponseBody(responseBody);
            reponseMessage.setCommand(command);

            // Validate the response
            if (this.requests.containsKey(messageId)) {
                if (response === 200) {
                    this.notificationService.process(reponseMessage);
                } else {
                    this.errorService.process(reponseMessage);
                }

            } else {
                console.error("[" + this.className + "] MessageId not exists = " + messageId);
            }

        } else {
            console.log("[" + this.className + "] User Session is invalid !!!");
        }
    }

    /**
     * On open handler
     */
    public onOpen(callback: (e: SJSOpenEvent) => any): void {
        this.addEvent('open', callback);
    }

    /**
     * On message handler
     */
    public onMessage(callback: (type: string, originator: string, data: any) => any): void {
        this.addEvent('client-message', callback);
    }

    /**
     * On close handler
     */
    public onClose(callback: (e: SJSCloseEvent) => any): void {
        this.addEvent('close', callback);
    }

    /**
     * Return if the websocket is openned
     */
    public isOpen(): boolean {
        return this.isOpened;
    }

    /**
     * Close the websocket
     */
    public close(): void {
        if (this.isOpened) {
            let request = new WsRequestMessage();
            console.log("-------------- Closing LoggedIn User Session on LogOut ---------------");
            this.send(request);
          
            this.eventBus.close();
            delete this.eventBus;
            this.isOpened = false;
        }
    }

    //////////////////////////////////////
    // Private
    //////////////////////////////////////

    /**
     * Call handler
     */
    private callHandlers(type: string, ...params: any[]) {
        if (this.handlers[type]) {
            this.handlers[type].forEach(function(cb) {
                cb.apply(cb, params);
            });
        }
    }

    /**
     * Add event
     */
    private addEvent(type: string, callback: Function): void {
        if (!this.handlers[type]) {
            this.handlers[type] = [];
        }
        this.handlers[type].push(callback);
    }

    /**
     * Put cookie
     */
    // putCookie(key: string, value: string) {
    //     this.cookieService.put(key, value);
    // }

    /**
     * Get cookie
     */
    getCookie(key: string) {
        return this.cookieService.get(key);
    }

    /**
     *  Websocket Re-connection
     */
    private reConnectionHandler(url, reConnInterval, reConnTrial) {
        console.log("-------------- Websocket Re-Connection In process ---------------");
        this.reConnIntervalID = setInterval(this.open(url, reConnInterval, reConnTrial), reConnInterval);
        if (this.reConnCount === reConnTrial) {
            clearInterval(this.reConnIntervalID);
            console.log("-------------- Websocket has been  Disconnected ---------------");
            this.reConnCount = 0;
            this.reConnectionFlag = false;
        }
    }


};

export default WebsocketProvider;
