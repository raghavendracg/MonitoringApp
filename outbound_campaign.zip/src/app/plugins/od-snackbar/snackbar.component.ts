import { Component, OnInit, Input, Output, OnChanges } from '@angular/core';
import { trigger, transition, style, animate } from '@angular/animations';
import { Observable } from 'rxjs/Observable';

@Component({
   selector: 'od-snackbar',
   templateUrl: './snackbar.component.html',
   styleUrls: ['./snackbar.component.scss'],
   animations: [
      trigger(
         'enterAnimation', [
            transition(':enter', [
               style({ transform: 'translateY(100%)', opacity: 0 }),
               animate('200ms', style({ transform: 'translateY(0)', opacity: 1 }))
            ]),
            transition(':leave', [
               style({ transform: 'translateY(0)', opacity: 1 }),
               animate('200ms', style({ transform: 'translateY(100%)', opacity: 0 }))
            ])
         ]
      )
   ]
})
export class SnackbarComponent implements OnInit, OnChanges {
   @Input() snackConfig = [];
   isVisible = false;
   timeOut = 500;
   message = '';
   constructor() {
   }
   ngOnInit() {
   }
   ngOnChanges(dd) {
      this.getSnackbarConfigData();
   }
   hideSnackbar() {
      new Observable(obs => {
         setTimeout(() => {
            this.isVisible = false;
            obs.complete()
         }, this.timeOut)
      }).subscribe();
   }
   getSnackbarConfigData() {
      if (this.snackConfig.length > 0) {
         this.isVisible = this.snackConfig[0];
         this.timeOut = this.snackConfig[1];
         this.message = this.snackConfig[2];
         if (this.snackConfig[1] === 'wait') {

         } else {
            this.hideSnackbar();
         }
      }
   }
}

// NOTE 
// (3) types of snackbar;

// (Type 1) this.snackConfigData = [true, "wait", "Campaigns is loading please wait..."]; 
// In "wait" we have to disable manually when data loaded.

// (Type 2) this.snackConfigData = [true, 1000, "Campaigns data loaded successfully"];
// When data is loaded than change message and replace "wait" to ms and call function again.

// (Type 3) this.snackConfigData = [ true, 2000, "More data is loading please wait..." ];
// if you want to display loading for particular time than use upper code

// Parameter
// 1 = visiable = true/false
// 2 = timeOut = ms or wait (whan you defined wait you have to end manuaaly)
// 3 = message = message which you want to show
