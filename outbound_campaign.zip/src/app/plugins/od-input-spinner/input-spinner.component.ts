import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'od-input-spinner',
  templateUrl: './input-spinner.component.html',
  styleUrls: ['./input-spinner.component.scss']
})
export class InputSpinnerComponent implements OnInit {
  @Input() min;
  @Input() max;
  @Input() value;
  @Input() step;
  @Output() spinnerValueOut: EventEmitter<any> = new EventEmitter<any>();
  spinnerInput;

  constructor() {}

  ngOnInit() {
    this.spinnerInput = this.value; // setting the default Value
    this.spinnerValueOut.emit(this.spinnerInput); 
  }

  increement() {
    (this.spinnerInput < this.max) 
    ? this.spinnerInput = this.spinnerInput + this.step 
    : this.spinnerInput = this.spinnerInput;
    
    this.spinnerValueOut.emit(this.spinnerInput); // Emiting Out the Spinner Value 
  }

  decreement() {
    (this.spinnerInput > this.min)
    ? this.spinnerInput = this.spinnerInput - this.step 
    : this.spinnerInput = this.spinnerInput;

    this.spinnerValueOut.emit(this.spinnerInput); // Emiting Out the Spinner Value 
  }

}
