import { Component, OnInit, Input, Output } from '@angular/core';

@Component({
  selector: 'od-custom-checkbox',
  templateUrl: './custom-checkbox.component.html',
  styleUrls: ['./custom-checkbox.component.scss']
})
export class CustomCheckboxComponent implements OnInit {
  @Input() name_in;
  @Input() id_in;
  checkBoxName;
  checkBoxId;
  
  constructor() { }

  ngOnInit() {
    console.log(this.id_in);
    this.checkBoxName = this.name_in;
    this.checkBoxId = 'checkBox';
  }

}
