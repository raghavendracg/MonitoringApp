import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'od-time-slot-selector',
  templateUrl: './time-slot-selector.component.html',
  styleUrls: ['./time-slot-selector.component.scss']
})
export class TimeSlotSelectorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
