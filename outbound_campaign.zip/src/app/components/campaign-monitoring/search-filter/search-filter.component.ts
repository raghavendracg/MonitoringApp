import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';

@Component({
   selector: 'od-search-filter',
   templateUrl: './search-filter.component.html',
   styleUrls: ['./search-filter.component.scss']
})
export class SearchFilterComponent implements OnInit {
   sortByKey: string;
   activateSearch = false;
   statusActive = 1; // Active - 1; Closed - 0; Draft - 2;
   isSortByVisible = false;
   campaignListSearch;
   @Input() readyStatus;
   @Output() changeCampaignStatusOut: EventEmitter<any> = new EventEmitter<any>();
   @Output() outSearchValue: EventEmitter<any> = new EventEmitter<any>();
   // Sortby
   sortByValues: Array<Object> = [];
   constructor(private translate: TranslateService) {
      // Populating the SortBy Values based on i18n Lang attribute selected.

      // to select default first option. 
   }

   ngOnInit() {
      this.changeCampaignStatusOut.emit(this.statusActive);
      this.outSearchValue.emit(this.campaignListSearch);
      this.sortByValues.push(
         { sortkey: 'startDate', value: 'START-DATE' },
         { sortkey: 'endDate', value: 'END-DATE' },
         { sortkey: 'cname', value: 'CAMPAIGN-NAME' },
         { sortkey: 'cpriority', value: 'CAMPAIGN-PRIORITY' }
      );

      this.sortByValues[0] !== undefined
         ? this.sortByKey = this.sortByValues[0]['value'] : this.sortByKey = '';
   }

   // Functions to toggle the Search Text
   openSearch() {
      this.activateSearch = true;
   }
   closeSearch() {
      this.activateSearch = false;
      if (this.campaignListSearch !== '') {
         this.campaignListSearch = '';
         this.emitSearchValue();
      }
   }

   // Function called on click of Status (Active,Closed, Drafts)
   changeStatus(event, activeId) {
      if (this.readyStatus && !event.target.classList.contains('active')) {
         this.statusActive = activeId;
         this.changeCampaignStatusOut.emit(this.statusActive);
      }
   }

   // SortBy dropdown code
   togglesortby(status) {
      if (status === 'off') {
         this.isSortByVisible = false;
      } else {
         this.isSortByVisible = !this.isSortByVisible;
      }
   }
   changeSortby(value) {
      this.sortByKey = value;
      this.togglesortby('off');
   }

   emitSearchValue() {
      this.outSearchValue.emit(this.campaignListSearch);
   }

}
