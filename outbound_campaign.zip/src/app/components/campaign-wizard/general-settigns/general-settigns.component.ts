import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
// import { GeneralSetting } from './general-setting.interface';

@Component({
  selector: 'od-general-settigns',
  templateUrl: './general-settigns.component.html',
  styleUrls: ['./general-settigns.component.scss']
})

export class GeneralSettignsComponent implements OnInit {
  generalSettingFormGroup: FormGroup;
  campaignStatus = 'draft';
  callTimeOutCheck = false;
  campaignStatusHrs = 2;
  campaignStatusMin = 0;
  campaignStatusSec = 0;
  descriptionCharCount = 512;
  formSubmitAttempt: boolean;
  constructor() { }

  
  isFieldDropdownSelected(){
    console.log(Validators.required);
    return Validators.required
  }

  ngOnInit() {
    this.generalSettingFormGroup = new FormGroup({
      campaignName: new FormControl('', Validators.compose([Validators.required,Validators.pattern('[^;|]+'),Validators.maxLength(64)])),
      campaignDesc: new FormControl('', [Validators.maxLength(512)]),
      campaignStatus: new FormControl({value: this.campaignStatus, disabled: true}),
      campaignSkill: new FormControl('', [this.isFieldDropdownSelected()])
    });
  }

  campaignDescCharCount(value) {
    this.descriptionCharCount = 512 - value.length;
  }

  isFieldValid(field: string) {
    return (!this.generalSettingFormGroup.get(field).valid && this.generalSettingFormGroup.get(field).touched) ||
    (this.generalSettingFormGroup.get(field).untouched && this.formSubmitAttempt);
  }
  isFieldPatternValid(field: string) {
    return (this.generalSettingFormGroup.get(field).hasError('pattern') && this.generalSettingFormGroup.get(field).touched) ||
    (this.generalSettingFormGroup.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  //
  validateAllFormFields(formGroup: FormGroup) {         
    Object.keys(formGroup.controls).forEach(field => {  
      const control = formGroup.get(field);             
      if (control instanceof FormControl) {             
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {        
        this.validateAllFormFields(control);            
      }
    });
  }


  onSubmit() {
  this.formSubmitAttempt = true;
  if (this.generalSettingFormGroup.valid) {
      console.log('form submitted');
    } else {
      this.validateAllFormFields(this.generalSettingFormGroup); 
    }
  }


  toggleCallTimeout() {
    this.callTimeOutCheck = !this.callTimeOutCheck;
  }

}
