export interface GeneralSetting {
  campaignName: string;
}
