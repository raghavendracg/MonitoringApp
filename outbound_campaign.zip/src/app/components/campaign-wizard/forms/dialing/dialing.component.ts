import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'od-dialing',
  templateUrl: './dialing.component.html',
  styleUrls: ['./dialing.component.scss']
})
export class DialingComponent implements OnInit {
  pageTitle = 'Dialing';
  limiterCheck= false;
  preview: Boolean;
  progressive: Boolean;
  predictive: Boolean;

  constructor() { }

  ngOnInit() {
    this.preview = true;
    this.progressive = false;
    this.predictive = false;
  }

  toggleLimiter() {
    this.limiterCheck = !this.limiterCheck;
  }
  toggleDialingModeSettings(dialerOption) {
    console.log(this.preview);
    if (dialerOption === 1) {
      this.preview = true;
      this.progressive = false;
      this.predictive = false;
    }else if (dialerOption === 2) {
      this.preview = false;
      this.progressive = true;
      this.predictive = false;    
    }else if (dialerOption === 3) {
      this.preview = false;
      this.progressive = false;
      this.predictive = true;   
    }
  }
}
