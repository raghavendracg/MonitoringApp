import { Component, OnInit, OnChanges, Input, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { getBasicData } from './data';
import { getBasicDataUpdate } from './dataUpdate';

@Component({
  selector: 'od-callback-cycle',
  templateUrl: './callback-cycle.component.html'
})

export class CallbackCycleComponent implements OnInit, OnChanges {
  pageTitle = 'Callback Cycle';
  // noOfAttempts = 3;
  attemptValue = 3;
  attemptModalValue = 3;
  openModal = false;
  closeModal;
  timeSlotValues = ['8.00', '8.30', '9.00', '9.30', '10.00', '10.30', '11.00', '11.30', '12.00',
    '12.30', '13.00', '13.30', '14.00', '14.30', '15.00', '15.30', '16.00', '16.30',
    '17.00', '17.30', '18.00', '18.30', '19.00'];
  timeSlotGroup = [];
  calendarData;
  callbackDaysGroup = [{
    attemptValue: this.attemptValue,
    callbackTimeSlot: [{
      callBackDays: {
        callBackActiveDays: [false, false, false, false, false, false, false],
        dayFullName: ['Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat', 'Sun'],
        dayshortName: ['M', 'T', 'W', 'T', 'F', 'S', 'S']
      },
      callBackTime: {
        startTime: [],
        endTime: []
      },
      timeSlotGroup: [{
        startTime: 'Start',
        endTime: 'End',
        startTimeOptions: false,
        endTimeOptions: false
      }]
    }]
  }];
  groupCount = [0];
  mapTimeslotToGroup = [
    {
      daysSelected: [],
      slots: [
        { startTime: 'Start', endTime: 'End' }
      ],
      popuptimeSlotFlag: [
        { popupStartFlag: false, popupEndFlag: false }
      ]
    }
  ]
  calenderScheduleData = [
    {
      dayId: 0,
      isActive: false,
      dayFullName: 'Monday',
      dayShortName: 'Mon',
      dayInitial: 'M',
      groupId: -1,
      dayTimeSlot: [
        { startTime: '', endTime: '' }
      ],
      popuptimeSlotFlag: [
        { popupStartFlag: false, popupEndFlag: false }
      ]
    },
    {
      dayId: 1,
      isActive: false,
      dayFullName: 'Tuesday',
      dayShortName: 'Tue',
      dayInitial: 'T',
      groupId: -1,
      dayTimeSlot: [
        { startTime: '', endTime: '' }
      ],
      popuptimeSlotFlag: [
        { popupStartFlag: false, popupEndFlag: false }
      ]
    },
    {
      dayId: 2,
      isActive: false,
      dayFullName: 'Wednesday',
      dayShortName: 'Wed',
      dayInitial: 'W',
      groupId: -1,
      dayTimeSlot: [
        { startTime: '', endTime: '' }
      ],
      popuptimeSlotFlag: [
        { popupStartFlag: false, popupEndFlag: false }
      ]
    },
    {
      dayId: 3,
      isActive: false,
      dayFullName: 'Thursday',
      dayShortName: 'Thu',
      dayInitial: 'T',
      groupId: -1,
      dayTimeSlot: [
        { startTime: '', endTime: '' }
      ],
      popuptimeSlotFlag: [
        { popupStartFlag: false, popupEndFlag: false }
      ]
    },
    {
      dayId: 4,
      isActive: false,
      dayFullName: 'Friday',
      dayShortName: 'Fri',
      dayInitial: 'F',
      groupId: -1,
      dayTimeSlot: [
        { startTime: '', endTime: '' }
      ],
      popuptimeSlotFlag: [
        { popupStartFlag: false, popupEndFlag: false }
      ]
    },
    {
      dayId: 5,
      isActive: false,
      dayFullName: 'Saturday',
      dayShortName: 'Sat',
      dayInitial: 'S',
      groupId: -1,
      dayTimeSlot: [
        { startTime: '', endTime: '' }
      ],
      popuptimeSlotFlag: [
        { popupStartFlag: false, popupEndFlag: false }
      ]
    },
    {
      dayId: 6,
      isActive: false,
      dayFullName: 'Sunday',
      dayShortName: 'Sun',
      dayInitial: 'S',
      groupId: -1,
      dayTimeSlot: [
        { startTime: '', endTime: '' }
      ],
      popuptimeSlotFlag: [
        { popupStartFlag: false, popupEndFlag: false }
      ]
    }
  ];
  calendarColumns = [];
  calendarOptions;
  calendarColWidths = [];
  attemptHeadContent;
  calendarSlotCellWidth = 110;
  calendarAttemptsCellWidth = 60;
  calendarCellPopupX = 0;
  calendarCellPopupY = 0;
  calendarPopupIsVisible = false;
  calendarCellSelectedRow;
  calendarCellSelectedColumn;
  calendarDummyTextValue;
  calendarDataUpdated;
  scheduleDayRounder = '';
  callbackScheduleSettings = '';
  constructor(
    @Inject(DOCUMENT) private document: any,
  ) { }
  ngOnInit() {
    this.calendarGenerateColumns(this.calenderScheduleData);
    this.generatecalendarHead(this.calenderScheduleData);
    this.generateScheduleDayRounder(this.calenderScheduleData, this.mapTimeslotToGroup);
    this.generateCallbackScheduleSettings(this.calenderScheduleData);
  }
  generateCallbackScheduleSettings(data) {
    this.callbackScheduleSettings += '<div class="day-selection-group">';
    this.callbackScheduleSettings += '<div class="schedule-day-rounder-wrapper">';
    for (let i = 0; i < data.length; i++) {
      this.callbackScheduleSettings += '<span class="schedule-day-rounder" (click)="toggleDays(' + i + ')">'
      this.callbackScheduleSettings += data[i].dayInitial
      this.callbackScheduleSettings += '</span>'
    }
    this.callbackScheduleSettings += '</div>'
    this.callbackScheduleSettings += '</div>';
  }

  generateScheduleDayRounder(data, timeSlotData) {
    this.scheduleDayRounder = '';
    let groupCount = 0;
    for (let i = 0; i < data.length; i++) {
      if (groupCount < data[i].groupId) {
        groupCount = data[i].groupId;
      }
    }

    for (let group = 0; group <= groupCount; group++) {
      this.scheduleDayRounder += '<div class="c_row"><div class="schedule-day-rounder-wrapper">';
      for (let i = 0; i < data.length; i++) {
        if (data[i].isActive === true && data[i].groupId === group) {
          this.scheduleDayRounder += '<span class="schedule-day-rounder schedule-day-rounder-active">' + data[i].dayInitial + '</span>';
        } else {
          this.scheduleDayRounder += '<span class="schedule-day-rounder">' + data[i].dayInitial + '</span>';
        }
      }
      this.scheduleDayRounder += '</div><div class="schedule-hours-wrapper">';
      // for (let i = 0; i < timeSlotData.length; i++) {
      //   for (let j = 0; j < timeSlotData[i].slots.length; j++) {
      //     this.scheduleDayRounder += '<span class="schedule-hours">' + timeSlotData[i].slots[j].startTime + 'h - ' + timeSlotData[i].slots[j].endTime + 'h</span>';
      //   }
      // }
      this.scheduleDayRounder += '</div></div>'
    }
  }
  generatecalendarHead(data) {
    this.attemptHeadContent = '<table><tr><td style="width:' + this.calendarAttemptsCellWidth + 'px">Days</td>';
    for (let i = 0; i < data.length; i++) {
      this.attemptHeadContent += '<td style="width:' + (this.calendarSlotCellWidth * data[i].dayTimeSlot.length) + 'px " colspan="' + data[i].dayTimeSlot.length + '">' + data[i].dayFullName + '</td>';
    }
    this.attemptHeadContent += '</tr>';
    this.attemptHeadContent += '<tr class="slot-header"><td style="width:' + this.calendarAttemptsCellWidth + 'px">Attempts</td>';
    for (let i = 0; i < data.length; i++) {
      for (let ii = 0; ii < data[i].dayTimeSlot.length; ii++) {
        this.attemptHeadContent += '<td style="width:' + this.calendarSlotCellWidth + '+px">';
        this.attemptHeadContent += data[i].dayTimeSlot[ii].startTime;
        this.attemptHeadContent += '-';
        this.attemptHeadContent += data[i].dayTimeSlot[ii].endTime;
        this.attemptHeadContent += '</td>';
      }
    }
    this.attemptHeadContent += '</tr></table>';
  }
  calendarGenerateColumns(data) {
    let totalColumns = 0;
    // this.calendarColumns.push({ data: 'id', readOnly: true }) to enable id working vishal 1 of 3
    // this.calendarColWidths.push(this.calendarAttemptsCellWidth); to enable id working vishal 2 of 3
  this.calendarColumns = [];
    for (let i = 0; i < data.length; i++) {
      for (let ii = 0; ii < data[i].dayTimeSlot.length; ii++) {
        this.calendarColumns.push({ 'data': data[i].dayShortName + ii });
        totalColumns++;
        this.calendarColWidths.push(this.calendarSlotCellWidth);
      }
    }
    console.log(this.calendarColumns);
    this.attemptValueIn(this.attemptValue);
  }

  // Function for number of attempts
  attemptValueIn(spinnerValue) {
    // this.noOfAttempts = [];
    this.attemptValue = spinnerValue;
    this.calendarData = getBasicData(this.attemptValue, this.calendarColumns);
    this.calendarOptions = {
      allowInsertColumn: false,
      allowInsertRow: false,
      maxRows: this.attemptValue,
      editor: false,
      rowHeaders: true,
      contextMenu: false
      // maxCols: 10
    }
    // this.calendarData = getBasicData(this.noOfAttempts);
    // this.callbackDaysGroup[0].attemptValue = spinnerValue;
    // for (let i = 1; i <= spinnerValue; i++) {
    //   this.noOfAttempts.push(i);
    // }
  }

  test(value, row, column) {
    this.calendarDataChange(value, row, column);
    console.log(this.calendarData);
  }
  ngOnChanges(e) {
    console.log(e)
  }
  calendarDataChange(value, row, column) {
    for (let i = 0; i < this.calendarData.length; i++) {
      if (row === i) {
        for (let ii = 0; ii < Object.keys(this.calendarData[i]).length; ii++) {
          if (column === ii) {
            this.calendarData[i][Object.keys(this.calendarData[i])[ii]] = value;
            console.log(this.calendarData);
          }
        }
        break;
      }
    }
    this.calendarData = getBasicDataUpdate(this.attemptValue, this.calendarData);
  }
  // Function to get the Emitted Value from Spinner Component
  spinnerIncreementIn(spinnerValue) {
    // this.noOfAttempts = [];
    // for (let i = 1; i <= spinnerValue; i++) {
    //   this.noOfAttempts.push(i);
    // }
    this.attemptValue = spinnerValue;
  }
  calendarAfterChange(e) {
    // console.log(e)
    // console.log(this.calendarData);
  }
  afterOnCellMouseDown(value) {
    console.log(value);
    this.calendarCellSelectedColumn = value[1].col;
    this.calendarCellSelectedRow = value[1].row;
    this.calendarPopupIsVisible = false;
    this.calendarCellPopupX = 0;
    this.calendarCellPopupY = 0;
  }
  afterOnCellCornerDblClick(value) {
    this.calendarPopupIsVisible = true;
    console.log(value);
    this.calendarCellPopupX = value[0].srcElement.offsetLeft;
    this.calendarCellPopupY = value[0].srcElement.offsetTop;
    console.log(value[0].srcElement.offsetTop);
    console.log(value[0].srcElement.offsetLeft);
  }
  calendarPopupValidBtn() {
    this.calendarDataChange(this.calendarDummyTextValue, this.calendarCellSelectedRow, this.calendarCellSelectedColumn);
    this.calendarPopupIsVisible = false;
  }

  attemptModalValueIn(value) {
    this.callbackDaysGroup[0].attemptValue = value;
    this.attemptModalValue = value;
  }

  toggleDays(dayIndex, groupIndex) {
    console.log(this.calenderScheduleData);
    if (this.calenderScheduleData[dayIndex].isActive && this.calenderScheduleData[dayIndex].groupId !== groupIndex) {
      alert('Already selected in Other Group');
    } else {
      this.calenderScheduleData[dayIndex].isActive = !this.calenderScheduleData[dayIndex].isActive;
      this.calenderScheduleData[dayIndex].groupId = groupIndex;
      this.mapTimeslotToGroup[groupIndex].daysSelected.push(dayIndex);
    }
  }

  // Function to select the timeSlots
  selectTimeSlot(time, slotOption, groupIndex, timeindex) {
    if (slotOption === 'start') {
      this.mapTimeslotToGroup[groupIndex].slots[timeindex].startTime = time;
      this.mapTimeslotToGroup[groupIndex].popuptimeSlotFlag[timeindex].popupStartFlag = false;
    } else if (slotOption === 'end') {
      this.mapTimeslotToGroup[groupIndex].slots[timeindex].endTime = time;
      this.mapTimeslotToGroup[groupIndex].popuptimeSlotFlag[timeindex].popupEndFlag = false;
    }
    console.log(this.calenderScheduleData)
  }

  // Function to open time Slot Options on click of Input
  openSlotOptions(slotOption, groupIndex, timeindex) {
    if (slotOption === 'start') {
      this.mapTimeslotToGroup[groupIndex].popuptimeSlotFlag[timeindex].popupStartFlag = !this.mapTimeslotToGroup[groupIndex].popuptimeSlotFlag[timeindex].popupStartFlag;
    } else if (slotOption === 'end') {
      this.mapTimeslotToGroup[groupIndex].popuptimeSlotFlag[timeindex].popupEndFlag = !this.mapTimeslotToGroup[groupIndex].popuptimeSlotFlag[timeindex].popupEndFlag;
    }
  }

  addDaysGroupBlock() {
    let isAllDaysChecked = false;
    for (let i = 0; i < this.calenderScheduleData.length; i++) {
      if (!this.calenderScheduleData[i].isActive) {
        isAllDaysChecked = true
      }
    }
    if (isAllDaysChecked) {
      const currentGroupCount = this.groupCount.length;
      this.groupCount.push(currentGroupCount);
      this.mapTimeslotToGroup.push({
        daysSelected: [],
        slots: [
          { startTime: 'Start', endTime: 'End' }
        ],
        popuptimeSlotFlag: [
          { popupStartFlag: false, popupEndFlag: false }
        ]
      });
    } else {
      alert('All days have been selected');
    }
  }
  removeDaysGroupBlock(index) {
    for (let i = 0; i < this.calenderScheduleData.length; i++) {
      if (this.calenderScheduleData[i].groupId === index) {
        this.calenderScheduleData[i].isActive = false;
        this.calenderScheduleData[i].groupId = -1;
      }
      if (this.calenderScheduleData[i].groupId >= index) {
        this.calenderScheduleData[i].groupId = this.calenderScheduleData[i].groupId - 1;
      }
    }
    if (index !== this.groupCount[this.groupCount.length - 1]) {
      for (let i = index + 1; i < this.groupCount.length; i++) {
        this.groupCount[i] = this.groupCount[i] - 1;
      }
    }
    this.groupCount.splice(index, 1);
    this.mapTimeslotToGroup.splice(index, 1);
  }

  // Function to add the timeSlot Block
  addTimeSlotBlock(groupIndex, timeindex) {
    const timeSlotTemplate = { startTime: 'Start', endTime: 'End' };
    const popuptimeFlagTemplate = { popupStartFlag: false, popupEndFlag: false };
    this.mapTimeslotToGroup[groupIndex].slots.push(timeSlotTemplate);
    this.mapTimeslotToGroup[groupIndex].popuptimeSlotFlag.push(popuptimeFlagTemplate);
  }

  validateModalSettings() {
    this.openModal = false;
    this.generateScheduleDayRounder(this.calenderScheduleData, this.mapTimeslotToGroup);
    for (let i = 0; i < this.mapTimeslotToGroup.length; i++ ) {
      for (let j = 0; j < this.mapTimeslotToGroup[i].daysSelected.length; j++ ) {
        this.calenderScheduleData[this.mapTimeslotToGroup[i].daysSelected[j]].dayTimeSlot = this.mapTimeslotToGroup[i].slots;
      }
    }
    console.log(this.calenderScheduleData)
    this.calendarGenerateColumns(this.calenderScheduleData);
    this.generatecalendarHead(this.calenderScheduleData);
  }
}
