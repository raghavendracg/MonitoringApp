// Type definitions for md5@2.0.0
// Project: https://github.com/coolaj86/jsMD5
// Definitions by: David Hainzl <https://github.com/dhainzl>

declare function md5 (message: string): string;