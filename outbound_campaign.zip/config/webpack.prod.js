var webpack = require('webpack');
var webpackMerge = require('webpack-merge');
var ExtractTextPlugin = require('extract-text-webpack-plugin');
var commonConfig = require('./webpack.common.js');
var helpers = require('./helpers');

// const ENV = process.env.NODE_ENV = process.env.ENV = 'production';
var ENV = process.env.npm_lifecycle_event;
var isProd = ENV === 'build';
var isDevWD = ENV === 'server-wd';


module.exports = webpackMerge(commonConfig, {
  devtool: 'source-map',
    output: {
    path: helpers.root('../src/main/resources/webroot'),
    publicPath: isProd ? './' : isDevWD ? 'http://localhost:8060/' : 'http://localhost:9099/',
    filename: isProd ? 'js/[name].[hash].js' : 'js/[name].js',
    chunkFilename: isProd ? '[id].[hash].chunk.js' : '[id].chunk.js'
  },

  plugins: [
    new webpack.NoEmitOnErrorsPlugin(),
    new webpack.optimize.UglifyJsPlugin({ // https://github.com/angular/angular/issues/10618
      mangle: {
        keep_fnames: true
      }
    }),
    new ExtractTextPlugin({filename: 'css/[name].[hash].css'}),
    new webpack.DefinePlugin({
      'process.env': {
        'ENV': JSON.stringify(ENV)
      }
    }),
    new webpack.LoaderOptionsPlugin({
      htmlLoader: {
        minimize: false // workaround for ng2
      }
    })
  ]
});

